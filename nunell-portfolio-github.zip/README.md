# Nunell Portfolio

Personal portfolio website for Roderic Nunell Soan.

## Files

- `index.html` — main website
- `style.css` — design and responsive layout
- `script.js` — small navigation interaction
- `assets/N U N E L.jpg` — profile photo

## Publish with GitHub Pages

1. Create a new repository on GitHub, for example `nunell-portfolio`.
2. Upload **all files and folders** from this project.
3. Make sure `index.html` is in the repository's root folder.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select your main branch and `/ (root)`, then save.
7. GitHub will provide your website URL.

Do not rename `index.html` or move the `assets` folder unless you also update the image path in `index.html`.
